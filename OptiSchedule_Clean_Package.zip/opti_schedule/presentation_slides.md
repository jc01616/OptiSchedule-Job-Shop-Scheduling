# OptiSchedule — Job Shop Scheduling Decision Intelligence System
## Executive Presentation & MBA Capstone Defense Deck

---

<!-- slide -->
# Slide 1: Title & Executive Overview

## OptiSchedule: Job Shop Scheduling Decision Intelligence System
**Operations Research & Constraint Programming applied to CNC Manufacturing**

* **Academic Program:** MBA Operations Management & Supply Chain Analytics
* **Project Team:** Group 4 Scheduling Capstone
* **Core Technologies:** Google OR-Tools CP-SAT, Python, Pandas, Matplotlib, Plotly
* **Key Achievements:**
  * Solved NP-hard Job Shop Scheduling Problem ($J_m || C_{\max}$) to proven global optimality (0.0% gap).
  * Implemented signed lateness ($L_j$), non-negative tardiness ($T_j$), and hourly throughput ($jobs/hr$).
  * Validated Goldratt's Theory of Constraints on capacity expansion (Scenario A).
  * Formulated operational governance protocol for disruption sensitivity (Scenario B).
  * Executed independent mathematical audit verifying **0 constraint violations across 234 operations**.

---

<!-- slide -->
# Slide 2: Problem Formulation & Benchmark Dataset

## CNC Machining Workshop Instance (8 Jobs, 4 Machines, 24 Operations)

* **Physical Shop Floor Resources:**
  * **M0 (Lathe):** Turning and facing (Total Workload = 16 min, 88.89% baseline load)
  * **M1 (Mill):** Milling and profiling (**Total Workload = 18 min, 100.00% binding bottleneck**)
  * **M2 (Drill Press):** Drilling and boring (Total Workload = 13 min, 72.22% baseline load)
  * **M3 (Grinder):** Surface grinding (**Total Workload = 18 min, 100.00% binding bottleneck**)
* **Job Characteristics:**
  * 8 distinct industrial parts (Shaft, Bracket, Flange, Gear, Pin, Housing, Cam, Bushing).
  * Total shop work content: **65 minutes**.
  * Total Work Content (TWK) customer due dates: Mean due date = **17.75 minutes**.
* **Theoretical Lower Bound:**
  $$LB = \max\left(\max_j \sum_{m} p_{j,m}, \max_m \sum_{j} p_{j,m}\right) = \max(9, 18) = \mathbf{18\text{ minutes}}$$

---

<!-- slide -->
# Slide 3: Scheduling Methodology Comparison & KPI Summary

## Complete Main Job-Shop Performance Matrix

All metrics deterministically calculated and independently audited from schedule timestamps:

| Scheduling Method | Makespan ($C_{\max}$) | vs. Baseline FCFS (%) | Avg Lateness ($L_j = C_j - d_j$) | Avg Tardiness ($T_j = \max(0, L_j)$) | Max Tardiness ($T_{\max}$) | % Tardy Jobs | Avg Machine Util ($\bar{U}$) | Benchmark Throughput | Optimality Status |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **FCFS (Baseline)** | 55 min | 0.00% | +12.38 min | 13.38 min | 39.0 min | 62.5% | 29.55% | 8.73 jobs/hr | Verified Feasible |
| **EDD** | 48 min | 12.73% | +7.50 min | 8.25 min | 23.0 min | 75.0% | 33.85% | 10.00 jobs/hr | Verified Feasible |
| **Palmer Heuristic**| 46 min | 16.36% | +8.25 min | 10.12 min | 34.0 min | 50.0% | 35.33% | 10.43 jobs/hr | Verified Feasible |
| **SPT** | 43 min | 21.82% | +5.75 min | 7.50 min | 20.0 min | 50.0% | 37.79% | 11.16 jobs/hr | Verified Feasible |
| **LPT** | 40 min | 27.27% | +8.50 min | 11.38 min | 24.0 min | 75.0% | 40.62% | 12.00 jobs/hr | Verified Feasible |
| **CP-SAT Optimal** | **18 min** | **67.27%** | **-2.25 min** | **0.75 min** | **3.0 min** | **25.0%** | **90.28%** | **26.67 jobs/hr** | **Proven Optimal (0.0% Gap)** |

### Core Mathematical Distinctions:
* **Signed Lateness ($L_j = C_j - d_j$):** CP-SAT achieves $-2.25\text{ min}$, meaning orders finish on average 2.25 minutes ahead of schedule.
* **Tardiness ($T_j = \max(0, L_j)$):** Eliminates early-order compensation; CP-SAT confines average tardiness to just $0.75\text{ min}$ (max tardiness of 3 min).
* **Throughput Benchmark ($N / (C_{\max}/60)$):** CP-SAT increases shop throughput from $8.73\text{ jobs/hr}$ to $26.67\text{ jobs/hr}$ (+205.5% productivity gain).

---

<!-- slide -->
# Slide 4: Baseline vs. Optimized Schedule: Visual Gantt Evidence

## Visualizing Combinatorial Efficiency

### Baseline FCFS Schedule (55 Minutes):
* **Mechanism:** Sequential list scheduling with job-level commitment locks machines into chronological arrival blocks.
* **Pathology:** Severe machine starvation and idle fragmentation (e.g., Lathe M0 sits idle for 17 consecutive minutes between min 18 and 35).
* **Consequence:** Makespan balloons to **55 minutes**; shop utilization plummets to **29.55%**.

### Optimized CP-SAT Schedule (18 Minutes):
* **Mechanism:** Exact mathematical constraint programming concurrently evaluates operation combinations using `IntervalVar` and `AddNoOverlap`.
* **Execution:** Tightly interleaves operations across all 4 machines with zero idle starvation on bottlenecks.
* **Result:** Mill (M1) and Grinder (M3) operate with **100.0% continuous utilization** from minute 0 to 18.
* **Optimality Proof:** Matches theoretical lower bound ($LB = 18\text{ min}$) with **0.00% optimality gap**.
* **Integrity:** Every operation is clearly labeled with Job and Operation index (`J{id}.O{op}`). 100% precedence and non-overlap compliance.

---

<!-- slide -->
# Slide 5: Bottleneck Analysis & Resource Addition (Scenario A)

## Theory of Constraints (ToC) Validation: Capital Investment in a Parallel Lathe

Testing whether adding an identical second Lathe (M4 parallel to M0) relieves queues and compresses makespan:

| Shop Resource / Parameter | Baseline CP-SAT (4 Machines) | Scenario A: +Lathe M4 (5 Machines) | Delta / Variance | Managerial Impact |
|:---|:---:|:---:|:---:|:---|
| **Makespan ($C_{\max}$)** | **18 minutes** | **18 minutes** | **0.00% (0 min gain)** | **Zero Throughput Improvement** |
| **Throughput (jobs/hr)** | 26.67 jobs/hr | 26.67 jobs/hr | 0.00% | System throughput strictly constrained |
| **M0 (Lathe 1) Workload** | 16 min (88.89% util) | 0 min (0.00% util) | -16 min | Solver shifted Lathe tasks to M4; total load is still 16 min |
| **M4 (Lathe 2) Workload** | Non-existent | 16 min (88.89% util) | +16 min | Combined Lathe capacity doubled; 20 min of idle slack created |
| **M1 (Mill) Workload** | **18 min (100.0% util)** | **18 min (100.0% util)** | **0 min** | **Primary Binding Constraint (Zero Slack)** |
| **M2 (Drill Press) Workload** | 13 min (72.22% util) | 13 min (72.22% util) | 0 min | Non-bottleneck machine (5 min idle slack) |
| **M3 (Grinder) Workload** | **18 min (100.0% util)** | **18 min (100.0% util)** | **0 min** | **Secondary Binding Constraint (Zero Slack)** |
| **Average Shop Utilization** | **90.28%** | **72.22%** | **-18.06%** | Utilization diluted due to redundant machine capital capacity |

### MBA Operations Management Insight:
* **Goldratt's Principle:** *"An hour saved on a non-bottleneck is an illusion."*
* Lathe was already non-binding (16 min load vs. 18 min system lower bound).
* **Capital Allocation Verdict:** Purchasing a second Lathe ($CapEx$) delivers **0% ROI**. Capital must instead be directed toward debottlenecking the Mill or Grinder.

---

<!-- slide -->
# Slide 6: Process Disruption & Operations Governance (Scenario B)

## Bottleneck Disruption & The >10% Escalation Threshold

Scenario B models process deterioration (tool wear, harder alloy stock, or feed-rate reduction) on the primary bottleneck, Machine 1 (Mill):

### Discrete Integer Rounding Impact:
* In integer minute scheduling, processing durations are scaled by +15% and rounded up: `math.ceil(duration * 1.15)`.
* Increases: $2 \to 3\text{ min}$ (+50.0%), $3 \to 4\text{ min}$ (+33.3%), $4 \to 5\text{ min}$ (+25.0%).
* Each of the 7 operations on Machine 1 gains exactly +1 minute.
* Aggregate Mill workload expands from **18 min to 25 min (+38.89%)**.
* Makespan expands 1:1 from **18 min to 25 min (+38.89%)**.

### Operations Governance Protocol (>10% Rule):
* **Governance Standard:** Any operational deviation causing a makespan deterioration of **greater than 10%** triggers **mandatory Operations Manager escalation, formal review, and sign-off**.
* **Severity Assessment:** At **+38.89%**, Scenario B severely breaches the governance threshold.
* **Mandatory Managerial Countermeasures:**
  1. *Tooling Maintenance:* Emergency tool replacement and spindle recalibration to restore nominal cutting speeds.
  2. *Overtime Authorization:* Authorize 1.5 hours of weekend overtime on Machine 1 to buffer delivery commitments.
  3. *Subcontracting:* Outsource rough milling operations on Flanges (J2) and Pins (J4) to qualified third-party vendors.

---

<!-- slide -->
# Slide 7: Dedicated Flow-Shop Benchmark Verification

## Johnson's Algorithm Optimality & Dominance Criteria

To prevent methodological conflation between the general job shop and pure flow shops, dedicated benchmark datasets were established:

### 1. Two-Machine Flow Shop ($F2 || C_{\max}$, 6 Jobs, Lathe $\to$ Mill):
* **Method:** Johnson's Rule (1954) partitions jobs into Set U ($A_i \le B_i$, sorted ascending $A$) and Set V ($A_i > B_i$, sorted descending $B$).
* **Results:**
  * **Johnson Sequence `[J5, J0, J2, J3, J4, J1]`:** **31 minutes** (Proven Optimal)
  * **FCFS Arrival Sequence `[J0, J1, J2, J3, J4, J5]`:** **34 minutes** (+8.82% makespan reduction by Johnson)
  * **Reverse Order Sequence `[J5, J4, J3, J2, J1, J0]`:** **35 minutes** (+11.43% makespan reduction by Johnson)

### 2. Three-Machine Flow Shop ($F3 || C_{\max}$, 5 Jobs, Turning $\to$ Milling $\to$ Grinding):
* **Dominance Test:**
  $$\min(A) = 5, \quad \max(B) = 3, \quad \min(C) = 4$$
  * Condition 1: $\min(A) \ge \max(B) \iff 5 \ge 3$ (**TRUE**)
  * Condition 2: $\min(C) \ge \max(B) \iff 4 \ge 3$ (**TRUE**)
* **Results:**
  * **Johnson 3M Reduction `[J3, J2, J4, J0, J1]`:** **42 minutes** (**Proven Optimal**, 6.67% reduction vs FCFS 45 min)
  * **Reverse Order `[J4, J3, J2, J1, J0]`:** **42 minutes** (**Optimal Alternative for This Instance**)
* **Methodological Scope:** Johnson's algorithm applies strictly to permutation flow shops; it is not a general solver for heterogeneous job shops.

---

<!-- slide -->
# Slide 8: Technical Audit, Verification & Project Limitations

## Rigorous Quality Assurance & Boundary Conditions

### Automated Independent Technical Audit:
* Executed via `python audit_runner.py`:
  * Validated 234 individual operations across 14 distinct schedule models.
  * Verified duration integrity, operation counts, non-negative start times, machine exclusivity, and job routings.
  * Recalculated makespans directly from operation completion timestamps.
  * **Audit Verdict: ZERO (0) constraint violations found across all models.**

### Critical Boundary Conditions & Limitations:
1. **Deterministic Execution:** Real-world stochasticity (machine breakdowns, raw material delays, tool breakage) is not modeled.
2. **Zero Sequence-Dependent Setup Times (SDST):** Tool changeover times between differing parts are assumed negligible.
3. **Absence of Financial/Cost Model:** Optimization is conducted on physical time ($C_{\max}$, tardiness). Capital costs, labor overtime wages, and inventory holding costs are excluded.
4. **Synthetic Benchmark Scope:** The **67.27% makespan reduction** mathematically proves the superiority of CP-SAT over naive sequential list scheduling on this benchmark. It **does not guarantee** identical 67% savings in live factory operations due to unmodeled shop-floor complexities.

---

<!-- slide -->
# Slide 9: Strategic Recommendations for Plant Leadership

## Summary of Actionable MBA Recommendations

1. **Adopt Constraint Programming as the Core Dispatching Engine:**
   * Transition shop floor scheduling from legacy FCFS / manual dispatching to Google OR-Tools CP-SAT.
   * Reduces makespan from 55 min to 18 min, lowers average tardiness from 13.38 min to 0.75 min, and triples throughput to 26.67 jobs/hr.

2. **Align Capital Expenditure with the Theory of Constraints:**
   * Reject un-validated equipment acquisition proposals (e.g., second Lathe).
   * Concentrate investment exclusively on debottlenecking Mill and Grinder capacities.

3. **Institutionalize the >10% Disruption Governance Threshold:**
   * Enforce automatic managerial escalation when tooling wear or setup delays inflate bottleneck run-times beyond 10%.
   * Maintain pre-approved contingency SOPs (overtime authorization and third-party subcontracting).

---
*End of Presentation — OptiSchedule Decision Intelligence System*
